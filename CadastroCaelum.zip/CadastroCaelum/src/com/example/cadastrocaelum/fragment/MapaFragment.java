package com.example.cadastrocaelum.fragment;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.util.Log;

import com.example.cadastrocaelum.dao.AlunoDAO;
import com.example.cadastrocaelum.dao.DatabaseHelper;
import com.example.cadastrocaelum.localization.AtualizadorDeLocalizacao;
import com.example.cadastrocaelum.modelo.Aluno;
import com.example.cadastrocaelum.util.Localizador;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapaFragment extends SupportMapFragment {
	
	/*@Override
	public void onCreate(Bundle savedInstanceState) {
		onResume();
		super.onCreate(savedInstanceState);
	}*/

	@Override
	public void onResume() {		
		//centraliza o mapa de acordo com a localizacao do gps do celular
		new AtualizadorDeLocalizacao(getActivity(), this);
		//centralizar o mapa na latitude e longitude retornadas		
		this.iniciaMapa();		
		super.onResume();
	}
	
	public void centralizaMapa(LatLng latlng){	
		GoogleMap googleMap = getMap();				
		googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng, 17));		
	}
	private void iniciaMapa(){
		GoogleMap googleMap = getMap();
		Localizador localizador = new Localizador(getActivity());
		LatLng latlng = null;
		List<Aluno> alunoEnderecos = buscaAlunosEnderecos();
		
		
		adicionaMarker(alunoEnderecos, latlng, googleMap, localizador);			
	}
	private void adicionaMarker
		(List<Aluno> alunoEnderecos, LatLng latlng, GoogleMap googleMap, Localizador localizador){
		for(Aluno alunoEndereco : alunoEnderecos){				
			latlng = localizador.getCoordenada(alunoEndereco.getEndereco());
			if(latlng != null){
				MarkerOptions marker = new MarkerOptions();
				marker.position(latlng);
				marker.title(alunoEndereco.getNome());
				marker.snippet(alunoEndereco.getEndereco());
				googleMap.addMarker(marker);
			}			
			Log.i("MAPA", "Coordenadas Endereco:" + latlng);
		}		
	}
	private List<Aluno> buscaAlunosEnderecos(){
		//busca lista de enderecos
		List<Aluno> alunos = new AlunoDAO(DatabaseHelper.getInstance(getContext())).lista();
		return alunos;
	}
}
