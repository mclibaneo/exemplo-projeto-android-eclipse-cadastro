package com.example.cadastrocaelum.fragment;

import com.example.cadastrocaelum.R;
import com.example.cadastrocaelum.modelo.Prova;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class DetalhesProvaFragment extends Fragment {

	private TextView detalheProvaMateriaView;
	private TextView detalheProvaDataView;
	private ListView detalheProvaTopicosView;
	private Prova prova;
	
	@Override	
	public View onCreateView(LayoutInflater inflater,
			 ViewGroup container, Bundle savedInstanceState) {
		
		View layoutDetalheProvas = inflater.inflate(R.layout.provas_detalhes, container, false);
		
		if(getArguments() != null)
			this.prova = (Prova) getArguments().getSerializable("prova");
		
		buscaViews(layoutDetalheProvas);
		populaViews(prova);		
		
		
		return layoutDetalheProvas;
	}
	
	private void buscaViews(View layout){		
		this.detalheProvaDataView = (TextView) 
				layout.findViewById(R.id.detalhe_prova_data);
		this.detalheProvaMateriaView = (TextView) 
				layout.findViewById(R.id.detalhe_prova_materia);
		this.detalheProvaTopicosView = (ListView) 
				layout.findViewById(R.id.detalhe_prova_topicos);
	}
	
	private void populaViews(Prova prova){
		if(prova != null){
			this.detalheProvaDataView.setText(prova.getData());
			this.detalheProvaMateriaView.setText(prova.getMateria());		
			ArrayAdapter<String> adapter = new ArrayAdapter<String>
			(getActivity(), android.R.layout.simple_list_item_1, prova.getTopicos());		
			this.detalheProvaTopicosView.setAdapter(adapter);
		}
		
	}
}
