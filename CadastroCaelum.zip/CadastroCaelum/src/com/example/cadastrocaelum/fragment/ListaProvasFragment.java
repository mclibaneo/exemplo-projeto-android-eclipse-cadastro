package com.example.cadastrocaelum.fragment;

import java.util.Arrays;
import java.util.List;

import com.example.cadastrocaelum.ProvasActivity;
import com.example.cadastrocaelum.R;
import com.example.cadastrocaelum.modelo.Prova;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ListaProvasFragment extends Fragment {
	
	private ListView listViewsProvas;
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
		
		//cria uma view para ser inflada
		View layoutProvas = inflater.inflate(R.layout.provas_lista, container, false);
		
		//busca a ListView da view inflada
		this.listViewsProvas = (ListView) layoutProvas.findViewById(R.id.lista_provas);
		
		//Criando objetos do tipo provas
		Prova prova1 = new Prova("20/04/2016", "Matem�tica");
		prova1.setTopicos(Arrays.asList("Algebra Linear", "Integral", "Diferencial"));		
		Prova prova2 = new Prova("10/05/2016", "Portugues");
		prova2.setTopicos(Arrays.asList("Complemento nominal", "Oracoes Subordinadas"));
		
		//cria um array de provas
		List<Prova> listaProvas = Arrays.asList(prova1, prova2);
		
		//adapta o array para ser mostrado na view
		ArrayAdapter<Prova> adapter = new ArrayAdapter<Prova>
										(getActivity(), android.R.layout.simple_list_item_1, listaProvas);
		
		//adiciona o array na view de provas
		this.listViewsProvas.setAdapter(adapter);
		
		//adicionando um evento de clique na lista
		this.listViewsProvas.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> adapter, View view, int posicao, long id){
				//obtem da lista a prova
				Prova prova = (Prova) adapter.getItemAtPosition(posicao);
				//Imprime mensagem com a prova selecionada
				Toast.makeText(getActivity(), "Prova: " + prova.getMateria(), Toast.LENGTH_SHORT)
				.show();
				//mostra os detalhes da prova
				ProvasActivity provasActivity = (ProvasActivity) getActivity();
				provasActivity.seleciona(prova);
			}
		});
		
		return layoutProvas;
	}
}
