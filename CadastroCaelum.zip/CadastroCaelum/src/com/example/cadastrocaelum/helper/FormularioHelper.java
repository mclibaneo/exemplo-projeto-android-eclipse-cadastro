package com.example.cadastrocaelum.helper;

import java.io.File;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import com.example.cadastrocaelum.R;
import com.example.cadastrocaelum.modelo.Aluno;

public class FormularioHelper extends Activity {
	
	private TextView campoId;
	private EditText campoNome;
	private EditText campoSite;
	private EditText campoTelefone;
	private EditText campoEndereco;
	private ImageView campoFoto;
	private RatingBar campoNota;
	private Aluno aluno;
	
	public FormularioHelper(Activity activity){
		this.campoId = (TextView) activity.findViewById(R.id.aluno_id);
		this.campoNome = (EditText) activity.findViewById(R.id.nome);
		this.campoSite = (EditText) activity.findViewById(R.id.site);
		this.campoTelefone = (EditText) activity.findViewById(R.id.telefone);
		this.campoEndereco = (EditText) activity.findViewById(R.id.endereco);
		this.campoFoto = (ImageView) activity.findViewById(R.id.foto);
		this.campoNota = (RatingBar) activity.findViewById(R.id.nota);	
		this.aluno = new Aluno();
	}
	
	public Aluno retornaAluno(){
		if(campoId.getText().toString() != "")			
			aluno.setId(Long.parseLong(campoId.getText().toString()));
		aluno.setNome(campoNome.getText().toString()); 
		aluno.setSite(campoSite.getText().toString());
		aluno.setTelefone(campoTelefone.getText().toString());
		aluno.setEndereco(campoEndereco.getText().toString());
		aluno.setNota(campoNota.getRating());
		
		return aluno;		
	}
	
	public void colocaAlunoNoFormulario(Aluno aluno){
		campoId.setText(aluno.getId().toString());
		campoNome.setText(aluno.getNome());
		campoSite.setText(aluno.getSite());
		campoTelefone.setText(aluno.getTelefone());
		campoEndereco.setText(aluno.getEndereco());
		if(aluno.getCaminhoFoto() != null && !aluno.getCaminhoFoto().isEmpty())
			carregaImagem(aluno.getCaminhoFoto());
		campoNota.setRating(aluno.getNota());		
	}
	
	public ImageView getCampoFoto(){
		return this.campoFoto;
	}
	public void carregaImagem(String caminho){
		Bitmap imagemFoto = BitmapFactory.decodeFile(caminho);
		Bitmap imagemFotoReduzida = Bitmap.createScaledBitmap(imagemFoto, 100, 100, true);
		aluno.setCaminhoFoto(caminho);
		campoFoto.setImageBitmap(imagemFotoReduzida);
	}

}
