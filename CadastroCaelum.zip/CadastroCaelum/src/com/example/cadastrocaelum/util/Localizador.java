package com.example.cadastrocaelum.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.maps.model.LatLng;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

public class Localizador {
	private Geocoder geocorder;	
	public Localizador(Context context){
		this.geocorder = new Geocoder(context);
	}	
	public LatLng getCoordenada(String locationName){
		List<Address> address;
		try {
			address = this.geocorder.getFromLocationName(locationName, 1);
			if(!address.isEmpty()){
				double latitude = address.get(0).getLatitude();
				double longitude = address.get(0).getLongitude();
				LatLng latlng = new LatLng(latitude, longitude);
				return latlng;
			}else{
				return null;
			}			
		} catch (IOException e) {
			throw new RuntimeException(e);
		}		
	}
}
