package com.example.cadastrocaelum.receiver;

import com.example.cadastrocaelum.R;
import com.example.cadastrocaelum.dao.AlunoDAO;
import com.example.cadastrocaelum.dao.DatabaseHelper;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.widget.Toast;
/*
 * Necessario configurar o receiver no AndroidManifest
*/
public class SMSReceiver extends BroadcastReceiver {
	@Override
	public void onReceive(Context context, Intent intent) {
		//Instancia uma classe DAO
		AlunoDAO alunoDAO = new AlunoDAO(DatabaseHelper.getInstance(context));
		//Extende da classe BroacastReceiver para receber uma mensagem
		//Utiliza um Bundle para ter acesso aos recursoso do dispositivo,
		//passando uma intent com os extras
		Bundle bundle = intent.getExtras();
		//Obtem informacoes das mensagens do aparelho, 
		//utiliza a chave pdus para obter mensagens 
		Object[] mensagens = (Object[]) bundle.get("pdus");
		//a menagem vem no formato de array de bytes
		//pegando apenas a primeira mensagem [0]
		byte[] mensagem = (byte[]) mensagens[0];
		//convertendo o byte em um objeto mensagem
		SmsMessage sms = SmsMessage.createFromPdu(mensagem);
		//usar o sms para imprimir o destinatario se ele for aluno 
		if(alunoDAO.isTelefoneAluno(sms.getDisplayOriginatingAddress())){
//			String mensagemToast = "Mensagem de: "+sms.getDisplayOriginatingAddress()+"\n"
//									+"Mensagem: "+sms.getDisplayMessageBody();
//			Toast.makeText(context, mensagemToast,Toast.LENGTH_LONG).show();	
			//Toca musica
			MediaPlayer mp = MediaPlayer.create(context, R.raw.sms);
			mp.start();
		}
	}
}
