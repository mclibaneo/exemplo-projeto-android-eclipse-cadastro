package com.example.cadastrocaelum;

import java.io.File;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.cadastrocaelum.dao.AlunoDAO;
import com.example.cadastrocaelum.dao.DatabaseHelper;
import com.example.cadastrocaelum.helper.FormularioHelper;
import com.example.cadastrocaelum.modelo.Aluno;

public class FormularioActivity extends Activity {
	
	private FormularioHelper helper;
	private AlunoDAO alunoDAO;
	private Button btnGravar;
	private ImageView btnFoto;
	private String localArquivoFoto;
	private Aluno alunoParaSerAlterado;
	final static private int REQUEST_CODE = 123;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.formulario);	
		
		//pega os valores da intent passada
		alunoParaSerAlterado = (Aluno) getIntent().getSerializableExtra("alunoSelecionado");
		
		//Helper eh utilizado para separar as funcoes de cada classe
		helper = new FormularioHelper(FormularioActivity.this);
		
		//DAO para movimentar banco de dados
		//Utilizando agora um singleton para instanciar apenas uma vez a conexao com o banco
		alunoDAO = new AlunoDAO(DatabaseHelper.getInstance(FormularioActivity.this));
		
		//Obtendo botao da tela
		btnGravar = (Button) findViewById(R.id.bntGravar);
		
		//alterar texto do botao caso seja passo uma intent para alterar
		if(alunoParaSerAlterado != null){
			helper.colocaAlunoNoFormulario(alunoParaSerAlterado);
			btnGravar.setText("Alterar");
		}
		
		//busca a imageview da tela atraves do helper
		btnFoto = helper.getCampoFoto();
		btnFoto.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				//informa o local do arquivo em um cartao sd
				localArquivoFoto = getExternalFilesDir(null) +"/"+ System.currentTimeMillis()+".jpg";
				//iniciar a camera
				Intent capturarFoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
				//a foto capturada sera salva no cartao sd informado
				capturarFoto.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(localArquivoFoto)));
				//inicia a activity mas esperando por um retorno
				startActivityForResult(capturarFoto, REQUEST_CODE);				
			}
		});
		
		//criando um listener para o botao
		btnGravar.setOnClickListener(new OnClickListener() {			
			@Override
			public void onClick(View v) {
				//usa helper para montar aluno				
				Aluno aluno = helper.retornaAluno();
				
				//Verifica se aluno possui id para ser alterado
				if(aluno.getId()!=null){
					alunoDAO.alterar(aluno);
				}else{
					//salva o aluno no banco de dados				
					alunoDAO.insere(aluno);	
				}
				
				//fecha conexao com banco de dados		
				Toast.makeText(FormularioActivity.this, "Aluno "+aluno.getNome()+" gravado com sucesso!!!", Toast.LENGTH_LONG).show();
				alunoDAO.close();				
				finish();
			}
		});		
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if(requestCode == REQUEST_CODE){
			if(resultCode == Activity.RESULT_OK){
				helper.carregaImagem(this.localArquivoFoto);
			}else{
				this.localArquivoFoto = null;
			}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}
	@Override
	protected void onDestroy() {		
		super.onDestroy();
	}
	
}
