package com.example.cadastrocaelum;

import com.example.cadastrocaelum.fragment.DetalhesProvaFragment;
import com.example.cadastrocaelum.fragment.ListaProvasFragment;
import com.example.cadastrocaelum.modelo.Prova;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

public class ProvasActivity extends FragmentActivity {

	@Override
	protected void onCreate(Bundle bundle){		
		super.onCreate(bundle);
		setContentView(R.layout.provas);	
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		//verifica se estamos em um tablet
		if(isTablet()){
			//colocando o ListaProvasFragment dentro do FrameLayout da view provas.xml			
			transaction.replace(R.id.provas_lista, new ListaProvasFragment());
			//colocando o DetalhesProvasFragment dentro do FrameLayout da view provas.xml
			transaction.replace(R.id.provas_detalhes, new DetalhesProvaFragment());			
			
		}else{
			transaction.replace(R.id.provas_view, new ListaProvasFragment());			
		}
		transaction.commit();		
	}
	
	public boolean isTablet(){
		//busca nos recursos da aplicacao o valor da variavel isTablet
		return getResources().getBoolean(R.bool.isTablet);
	}
	
	public void seleciona(Prova prova){
		//cria um objeto com a prova como argumento
		Bundle argumentos = new Bundle();
		argumentos.putSerializable("prova", prova);
		//adiciona os argumentos no fragment
		DetalhesProvaFragment detalhesProva = new DetalhesProvaFragment();
		detalhesProva.setArguments(argumentos);
		//inicia a fragmentacao da view substituindo o provas_view pelo DetalhesProvaFragment
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
			transaction.replace(R.id.provas_view, detalhesProva);
			if(!isTablet())
				transaction.addToBackStack(null);
		transaction.commit();
	}
}
