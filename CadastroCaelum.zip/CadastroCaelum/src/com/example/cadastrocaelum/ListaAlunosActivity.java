package com.example.cadastrocaelum;
import java.util.ArrayList;

import com.example.cadastrocaelum.R;
import com.example.cadastrocaelum.adapter.ListaAlunosAdapter;
import com.example.cadastrocaelum.converter.AlunoConverter;
import com.example.cadastrocaelum.dao.AlunoDAO;
import com.example.cadastrocaelum.dao.DatabaseHelper;
import com.example.cadastrocaelum.modelo.Aluno;
import com.example.cadastrocaelum.support.WebClient;
import com.example.cadastrocaelum.task.EnviaContatosTask;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


public class ListaAlunosActivity extends Activity{
	private Aluno alunoSelecionado;
	private AlunoDAO alunoDAO;
	private ActionMode mActionMode;
	private Intent intent;

	@Override
	public void onCreate(Bundle savedInstanceState){
		//Herda o comportamento do metodo
		super.onCreate(savedInstanceState);
		
		//Seleciona a view que sera iniciada
		//dentro do contexto da aplicacao
		setContentView(R.layout.listagem_alunos);
		
		//carrega lista de aluno
		carregaLista();		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		//Inflater eh utilizado para criar um menu a partir de um arquivo .xml
		MenuInflater inflater = this.getMenuInflater();
		//Aqui realiza a criacao do menu
		inflater.inflate(R.menu.menu_principal, menu);
		return true;
				
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {		
		//Toast.makeText(ListaAlunosActivity.this, "Item: "+item.getTitle(), Toast.LENGTH_SHORT).show();
		Log.i("MENU", "Item Menu"+item.getMenuInfo());
		
		//selecionamos o id do item do menu no qual usuario deu um clique
		switch (item.getItemId()) {
		case R.id.menu_novo:
			//usamos Intent quando temos a intencao de ir para algum lugar
			//O intent vai de um contexto para uma classe
			intent = new Intent(ListaAlunosActivity.this, FormularioActivity.class);
			//inicia a activity
			startActivity(intent);
			return true;
		case R.id.menu_enviar_alunos:
			//utiliza uma classe para enviar ao servidor uma lista de alunos em background 
			new EnviaContatosTask(this).execute();
			return true;
		case R.id.menu_receber_provas:
			intent = new Intent(ListaAlunosActivity.this, ProvasActivity.class);
			startActivity(intent);
			return true;
		case R.id.menu_mapa:
			intent = new Intent(ListaAlunosActivity.this, AlunosProximosActivity.class);
			startActivity(intent);
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}			
	}
	
	@Override
	protected void onResume() {
		//carrega a lista aqui tbm, 
		//pois ao fechar a aplicacao e retornar para ela eh necessario carregar a lista
		carregaLista();
		super.onResume();
	}
	
	private void carregaLista(){
		//Criando uma lista imaginaria de alunos
		//String[] alunos = {"Pedro", "Paulo", "Joao"};
		alunoDAO = new AlunoDAO(DatabaseHelper.getInstance(ListaAlunosActivity.this));
		ArrayList<Aluno> alunos = alunoDAO.lista();
		
		//Busca a view de lista
		final ListView listaAlunos = (ListView) findViewById(R.id.lista);		
			
		//Utiliza o Adapter para adptar cada objeto do array em um item da ListView
		//Os parametros do Adapter sao: contexto, tipo de adaptacao, objetos para adaptar
//		ArrayAdapter<Aluno> adapter = 
//				new ArrayAdapter<Aluno>(this, android.R.layout.simple_list_item_1, alunos);
		
		//Utilizando o adpter criado para adptar a lista de alunos em uma view
		ListaAlunosAdapter adapter = new ListaAlunosAdapter(alunos, ListaAlunosActivity.this);
		
		//Adicionando o adapter ao contexto da ListaAlunos
		listaAlunos.setAdapter(adapter);
		
		//Ao clique longo
		aoCliqueLongo(listaAlunos);
		
		//Ao clique curto
		aoCliqueCurto(listaAlunos);
	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,ContextMenuInfo menuInfo) {
		
		//Adicionando itens de manu 
		menu.add("Ligar");
		menu.add("Enviar SMS");
		menu.add("Enviar E-mail");
		menu.add("Achar no Mapa");
		menu.add("Navegar no site");		
		//menu.add("Deletar");
		
		//Adicionando funcao ao item de menu deleter
		MenuItem deletar = menu.add("Deletar");
		deletar.setOnMenuItemClickListener(new OnMenuItemClickListener() {			
			@Override
			public boolean onMenuItemClick(MenuItem item) {
				AlunoDAO alunoDAO = new AlunoDAO(DatabaseHelper.getInstance(ListaAlunosActivity.this));
				alunoDAO.deletar(alunoSelecionado);
				return false;
			}
		});
		super.onCreateContextMenu(menu, v, menuInfo);
	}
	private void aoCliqueCurto(ListView listaAlunos){
		//Usando Listener para receber informacoes de click na lista
		listaAlunos.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				//Utilizando Toast para mostrar mensagem popup ao usuario
				//Os parametros sao: contexto, texto da mensagem e duracao da exibicao
				//Utilizamos como contexto a propria view
				alunoSelecionado = (Aluno) parent.getItemAtPosition(position);
				//Criamos a intencao de ir para o formulario para editar aluno
				//enviamos junto a intencao o objeto serializado!
				Intent editar = new Intent(ListaAlunosActivity.this, FormularioActivity.class);
				editar.putExtra("alunoSelecionado", alunoSelecionado);
				//vai para activity
				startActivity(editar);				
				Toast.makeText(ListaAlunosActivity.this,"Posi��o selecionada: "+(position+1), Toast.LENGTH_SHORT).show();
				Log.i("ITEM_LISTA","Posi��o: " + (position+1));				
			}
		});	
	}
	
	private void aoCliqueLongo(ListView listaAlunos){
		//Utilizaremos agora um novo tipo de Listener que eh ativado apos um clique longo
		listaAlunos.setOnItemLongClickListener(new OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					int position, long id) {
				alunoSelecionado = (Aluno) parent.getItemAtPosition(position);
				//Informa usuario
				Toast.makeText(ListaAlunosActivity.this, "Aluno: " + alunoSelecionado, Toast.LENGTH_SHORT).show();
				Log.i("ITEM_LISTA","Aluno: "+parent.getItemAtPosition(position));
				//registrar um menu de contexto
				//para isso eh necessario buscar uma listview
				//registerForContextMenu(listaAlunos);
				if(mActionMode != null){
					return false;
				}
				mActionMode = ListaAlunosActivity.this.startActionMode(mActionModeCallback);
		        view.setSelected(true);
		        return true;							
				//Para assumir somente o comportamento do clique longo, 
				//se falso assume comportamento do clique longo e curto
				
			}
		});
	}
	
	private ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {

	    // Called when the action mode is created; startActionMode() was called
	    @Override
	    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
	        // Inflate a menu resource providing context menu items
	        MenuInflater inflater = mode.getMenuInflater();
	        inflater.inflate(R.menu.menu_contexto_edicao, menu);
	        return true;
	    }

	    // Called each time the action mode is shown. Always called after onCreateActionMode, but
	    // may be called multiple times if the mode is invalidated.
	    @Override
	    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
	        return false; // Return false if nothing is done
	    }
	    
	    private void enviaIntentActivity(Intent intent){
	    	//verifica se existe uma acivity relacionada
	    	if(intent.resolveActivity(getPackageManager())!=null){
        		startActivity(intent);
        	}else{
        		Toast.makeText(ListaAlunosActivity.this, "N�o foi poss�vel realizar opera��o.", Toast.LENGTH_SHORT).show();
        	}
	    }

	    // Called when the user selects a contextual menu item
	    @Override
	    public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
	        switch (item.getItemId()) {
		        case R.id.menu_telefonar:
	               //telefona
		        	Intent telefonarIntent = new Intent(Intent.ACTION_CALL);
		        	telefonarIntent.setData(Uri.parse("tel:"+alunoSelecionado.getTelefone()));		        	
		        	enviaIntentActivity(telefonarIntent);		        	
	                mode.finish(); // Action picked, so close the CAB
	                return true;	            
	            case R.id.menu_mensagem:
	            	//envia mensagem
	            	Intent msmIntent =  new Intent(Intent.ACTION_SEND);
	            	
	            	//formatando mensagem
	            	String title = getResources().getString(R.string.chooser_mensagem);	           	
	            
	            		            	
	            	//envia o json na mensagem
	            	String mensagem = "O(a) aluno(a) "+alunoSelecionado.getNome()
	            						+" tirou nota "+alunoSelecionado.getNota().toString()+".";
	            	
	            	//usando um chooser para oferecer uma lista de operacoes para concluir intencao
	            	Intent chooser = Intent.createChooser(msmIntent, title);
	            	
	            	//configurando intent final
	            	msmIntent.putExtra(Intent.EXTRA_TEXT, mensagem);	            	
	            	msmIntent.setType("text/plain");
	            	enviaIntentActivity(chooser);
	            	
	                mode.finish(); // Action picked, so close the CAB
	                return true;	                
	            case R.id.menu_mapa:
		            //encontrar no mapa
	            	Intent mapaIntent = new Intent(Intent.ACTION_VIEW);
	            	mapaIntent.setData(Uri.parse("geo:0,0?z=14&q="+alunoSelecionado.getEndereco()));
	            	enviaIntentActivity(mapaIntent);
	                mode.finish(); // Action picked, so close the CAB
	                return true;
	            case R.id.menu_site:
		            //abrir site
	            	Intent siteIntent = new Intent(Intent.ACTION_VIEW);
	            	String siteAluno = alunoSelecionado.getSite();
	            	if(!siteAluno.startsWith("http://")){
	            		siteAluno = "http://"+siteAluno;
	            	}	            	
	            	siteIntent.setData(Uri.parse(siteAluno));
	            	enviaIntentActivity(siteIntent);
	                mode.finish(); // Action picked, so close the CAB
	                return true;
	        	case R.id.menu_alterar:
	                //Altera aluno 
					Intent editar = new Intent(ListaAlunosActivity.this, FormularioActivity.class);
					editar.putExtra("alunoSelecionado", alunoSelecionado);
					//vai para activity
					startActivity(editar);	
	                mode.finish(); // Action picked, so close the CAB
	                return true;
	            case R.id.menu_apagar:
	                //Apaga Aluno
	            	alunoDAO.deletar(alunoSelecionado);
					carregaLista();	
	                mode.finish(); // Action picked, so close the CAB
	                return true;
	            default:
	                return false;
	        }
	    }

	    // Called when the user exits the action mode
	    @Override
	    public void onDestroyActionMode(ActionMode mode) {
	        mActionMode = null;
	    }
	};
}
