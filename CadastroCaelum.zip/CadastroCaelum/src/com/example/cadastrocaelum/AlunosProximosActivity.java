package com.example.cadastrocaelum;

import com.example.cadastrocaelum.fragment.MapaFragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

public class AlunosProximosActivity extends FragmentActivity {
	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.map_layout);
		
		//Substitui o framelayout pelo fragmento do mapa
		MapaFragment mapaFragment = new MapaFragment();
		FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
		transaction.replace(R.id.mapa, mapaFragment);
		transaction.commit();
		
	}
}
