package com.example.cadastrocaelum.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper
{
	private static DatabaseHelper sInstance;	
	private static final String DATABASE_NAME = "CadastroCaelum";
	private static final String DATABASE_TABLE = "Alunos";
	private static final int DATABASE_VERSION = 1;
	
	public static synchronized DatabaseHelper getInstance(Context context){
		/*
		 * Usando contexto para evitar acidentalmente 
		 * modificacoes em outras partes do programa.
		 * */
		if(sInstance == null)
			sInstance = new DatabaseHelper(context.getApplicationContext());
		return sInstance;
	}
	
	/*
	 * Construtor deve ser privado para evitar instanciacoes diretas.
	 * chame o metodo getInstance() ao inves deste construtor.
	 * */
	private DatabaseHelper(Context context){
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		//Utiliza este metodo para criar uma tabela nova
		String createTableAlunos = "CREATE TABLE "+DATABASE_TABLE+"(" +
									"id INTEGER PRIMARY KEY," +
									"nome TEXT UNIQUE NOT NULL," +
									"telefone TEXT," +
									"endereco TEXT," +
									"site TEXT," +
									"nota REAL," +
									"caminhoFoto TEXT);";
		//executa a string sql
		db.execSQL(createTableAlunos);		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		String updateTableAlunos = "DROP TABLE IF EXISTS "+DATABASE_TABLE;
		db.execSQL(updateTableAlunos);
		onCreate(db);
		
	}

}
