package com.example.cadastrocaelum.dao;

import java.util.ArrayList;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.cadastrocaelum.modelo.Aluno;

public class AlunoDAO {

	private final DatabaseHelper dbHelper;
	private SQLiteDatabase db;
	
	public AlunoDAO(DatabaseHelper dbHelper) {
		this.dbHelper = dbHelper;
	}
		
	public void insere(Aluno aluno){
		//Utiliza o content values
		ContentValues valores = toValues(aluno);
		//invoca getWritableDatabase para ter acesso ao banco de dados
		db = dbHelper.getWritableDatabase();
		//Primeiro parametro do sqlitedatabase eh o nome da coluna a ser inserida
		//o segundo parametro eh para evitar inserir todos os valores nulos
		//o terceiro parametro sao os valores mapeados
		db.insert("Alunos", null, valores);
		//libera objeto
		//db.close();		
	}
	
	private ContentValues toValues(Aluno aluno){
		//Utiliza um content values para mapear objetos em tabelas
		ContentValues cv = new ContentValues();
		//cv.put("id", aluno.getId());
		cv.put("nome", aluno.getNome());
		cv.put("telefone", aluno.getTelefone());
		cv.put("endereco", aluno.getEndereco());
		cv.put("site", aluno.getSite());
		cv.put("nota", aluno.getNota());
		cv.put("caminhoFoto", aluno.getCaminhoFoto());
		return cv;
	}
	
	public void close(){
		dbHelper.close();
	}
	
	public ArrayList<Aluno> lista(){
		ArrayList<Aluno> alunos = new ArrayList<Aluno>();
		String selectAllAlunos = "SELECT * FROM Alunos";
		db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery(selectAllAlunos, null);
		while(cursor.moveToNext()){
			Aluno aluno = new Aluno();
			aluno.setId(cursor.getLong(cursor.getColumnIndex("id")));
			aluno.setNome(cursor.getString(cursor.getColumnIndex("nome")));
			aluno.setTelefone(cursor.getString(cursor.getColumnIndex("telefone")));
			aluno.setEndereco(cursor.getString(cursor.getColumnIndex("endereco")));
			aluno.setSite(cursor.getString(cursor.getColumnIndex("site")));
			aluno.setNota(cursor.getFloat(cursor.getColumnIndex("nota")));
			aluno.setCaminhoFoto(cursor.getString(cursor.getColumnIndex("caminhoFoto")));		
			alunos.add(aluno);			
		}
		return alunos;
	}
	
	public ArrayList<String> listaNomeAlunos(){
		ArrayList<Aluno> alunos = lista();
		ArrayList<String> alunosNomes = new ArrayList<String>();
		for(Aluno aluno : alunos){
			alunosNomes.add(aluno.getNome());
		}
		return alunosNomes;
	}
	
	public void deletar(Aluno aluno){
		db = dbHelper.getWritableDatabase();
		String[] args = {aluno.getId().toString()};
		db.delete("Alunos", "id=?", args);
	}
	
	public void alterar(Aluno aluno){
		db = dbHelper.getWritableDatabase();
		ContentValues values = toValues(aluno);		
		String[] args = {aluno.getId().toString()};
		db.update("Alunos", values, "id=?", args);
		
	}
	
	public boolean isTelefoneAluno(String telefone){
		db = dbHelper.getReadableDatabase();
		//Cria um consulta
		String sql = "SELECT telefone FROM Alunos WHERE telefone = ?";
		//Informa argumento da clausula WHERE
		String[] args = new String[]{telefone};
		//Faz uma consulta sql para verificar a existencia do telefone
		Cursor rawQuery = db.rawQuery(sql,args);
		//Salva o retorno da consulta em um inteiro
		int retornoConsulta = rawQuery.getCount();
		//Fecha a consulta
		rawQuery.close();
		//Retorna o valor
		return retornoConsulta>0;
		
	}
	
}
