package com.example.cadastrocaelum.adapter;

import java.util.List;

import com.example.cadastrocaelum.modelo.Aluno;

import com.example.cadastrocaelum.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ListaAlunosAdapter extends BaseAdapter {

	private Activity activity;
	private List<Aluno> listaAlunos;
	
	public ListaAlunosAdapter(List<Aluno> listaAlunos, Activity activity){
		this.listaAlunos = listaAlunos;
		this.activity = activity;
	}
	@Override
	public int getCount() {
		return listaAlunos.size();
	}

	@Override
	public Object getItem(int position) {
		return listaAlunos.get(position);
	}

	@Override
	public long getItemId(int position) {
		return listaAlunos.get(position).getId();
	}

	
	public View getView(int position, View convertView, ViewGroup parent) {	
		//Cria uma view na activity passada usando o layout de xml
		View view = activity.getLayoutInflater().inflate(R.layout.item, null);
		//Busca aluno atual
		Aluno aluno = listaAlunos.get(position);
		//Modifica  o TextView do layout
		TextView textViewNome = (TextView) view.findViewById(R.id.item_nome);
		textViewNome.setText(aluno.getNome());
		
		TextView textViewTelefone = (TextView) view.findViewById(R.id.item_telefone);
		if(textViewTelefone != null)
			textViewTelefone.setText(aluno.getTelefone());
		
		TextView textViewSite = (TextView) view.findViewById(R.id.item_site);
		if(textViewSite != null)
			textViewSite.setText(aluno.getSite());		
		
		//Modifica o ImageView para mostrar uma imagem bitmap
		Bitmap bm;
		if(aluno.getCaminhoFoto()!=null){
			//Adiona foto de acordo com o caminho do aluno 
			bm = BitmapFactory.decodeFile(aluno.getCaminhoFoto());
		}else{
			//Se o aluno nao possui foto usa a padrao
			bm = BitmapFactory.decodeResource(activity.getResources(), R.drawable.ic_no_image);
		}
		ImageView imageView = (ImageView) view.findViewById(R.id.item_foto);
		imageView.setImageBitmap(bm);
		//Zebrando a listView
		if(position%2==0)
			view.setBackgroundColor(activity.getResources().getColor(R.color.linha_par));
		else
			view.setBackgroundColor(activity.getResources().getColor(R.color.linha_impar));
		
		return view;
	}
	
}
