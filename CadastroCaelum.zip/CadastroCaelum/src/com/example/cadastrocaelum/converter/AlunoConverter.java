package com.example.cadastrocaelum.converter;

import java.util.List;

import org.json.JSONException;
import org.json.JSONStringer;

import com.example.cadastrocaelum.modelo.Aluno;

public class AlunoConverter {
	
	public String toJSON(List<Aluno> alunos){
		try {
			//utiliza biblioteca nativa JSON
			JSONStringer jsonStringer = new JSONStringer();
			//Criamos um objeto json que contem um array de aluno dentro de um array list
			jsonStringer.object().key("list").array().object().key("aluno").array();
			//iteramos entre uma lista de alunos para inseri-los como objetos json
			for(Aluno aluno : alunos){
				//Cria objeto JSON com varios pares chave/valor
				jsonStringer.object()
								.key("id").value(aluno.getId())
								.key("nome").value(aluno.getNome())
								.key("site").value(aluno.getSite())
								.key("telefone").value(aluno.getTelefone())
								.key("endereco").value(aluno.getEndereco())
								.key("nota").value(aluno.getNota())
								.key("foto").value(aluno.getCaminhoFoto())
							.endObject();
				//todo objeto JSON necessita ser encerrado com endObject						
			}
			//fechamos todos os objetos criados e adicinamos a referencia JSON em uma string
			String json = jsonStringer.endArray().endObject().endArray().endObject().toString();
			return json;
		} catch (JSONException e) {
			throw new RuntimeException(e);
		}
	}
}
