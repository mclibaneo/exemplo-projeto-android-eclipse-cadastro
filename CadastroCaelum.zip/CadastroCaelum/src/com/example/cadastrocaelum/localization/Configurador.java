package com.example.cadastrocaelum.localization;

import android.os.Bundle;

import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.location.LocationRequest;

public class Configurador implements ConnectionCallbacks {

	private AtualizadorDeLocalizacao atualizador;
	
	public Configurador(AtualizadorDeLocalizacao atualizador){
		this.atualizador = atualizador;
	}
	@Override
	public void onConnected(Bundle bundle) {	
		LocationRequest request = LocationRequest.create();
		//Intervalo de 2 segundos para atualizar o request
		request.setInterval(2000);
		//Prioridade de alta precisao
		//Utilizando melhor provider disponivel
		request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		//Distancia minima de 50 metros
		request.setSmallestDisplacement(50);
		
		atualizador.inicia(request);
	}

	@Override
	public void onConnectionSuspended(int arg0) {		
	}
	
	
}
