package com.example.cadastrocaelum.task;

import java.util.List;

import com.example.cadastrocaelum.converter.AlunoConverter;
import com.example.cadastrocaelum.dao.AlunoDAO;
import com.example.cadastrocaelum.dao.DatabaseHelper;
import com.example.cadastrocaelum.modelo.Aluno;
import com.example.cadastrocaelum.support.WebClient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.Toast;

public class EnviaContatosTask extends AsyncTask<Object, Object, String> {
	private ProgressDialog progress;
	private Activity context;
	private final String endereco = "http://www.caelum.com.br/mobile";	
	public EnviaContatosTask(Activity context){
		this.context = context;
	}
	@Override
	protected String doInBackground(Object... params) {
		//Enviar alunos para o servidor
		List<Aluno> alunos = new AlunoDAO(DatabaseHelper.getInstance(context)).lista();
		String alunosJSON = new AlunoConverter().toJSON(alunos);
		WebClient webClient = new WebClient(endereco);
		String response = webClient.post(alunosJSON);
		return response;
	}
	@Override
	protected void onPreExecute(){
		//criar uma barra de progresso
		progress = ProgressDialog.
				show(context, "Aguarde...", "Enviando dados para a web!!!", true, true);
	}
	@Override
	protected void onPostExecute(String result){
		//mostra na tela o resultado
		Toast.makeText(context, result, Toast.LENGTH_LONG).show();
		//cancela a barra de progresso
		progress.dismiss();
	}	
}
