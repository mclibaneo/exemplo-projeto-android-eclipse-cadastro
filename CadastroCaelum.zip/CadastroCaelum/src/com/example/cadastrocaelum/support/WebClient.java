package com.example.cadastrocaelum.support;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class WebClient {
	private final String url;
	
	public WebClient(String url){
		this.url = url;
	}
	
	//vamos enviar um objeto JSON para o servidor
	public String post(String json){
		try {
			DefaultHttpClient httpClient = new DefaultHttpClient();
			//configura um objeto post para ser enviado
			HttpPost post = new HttpPost(url);
			//configura requisicao post para aceitar objeto json
			post.setHeader("Accept","application/json");
			//configura requisicao post para retornar resposta do tipo json
			post.setHeader("Content-type", "application/json");			
			post.setEntity(new StringEntity(json));
			HttpResponse response = httpClient.execute(post);
			String jsonResponse = EntityUtils.toString(response.getEntity());
			return jsonResponse;
		} catch (UnsupportedEncodingException eUnsupportedEncoding ) {
			throw new RuntimeException(eUnsupportedEncoding);
		} catch (ClientProtocolException eClientProtocol) {
			throw new RuntimeException(eClientProtocol);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
}
